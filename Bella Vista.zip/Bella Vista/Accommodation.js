const filterButtons = document.querySelectorAll(".filter-btn");
const categoryBlocks = document.querySelectorAll(".category-block");
const bookingModal = document.querySelector("#booking-modal");
const bookingForm = document.querySelector("#booking-form");
const bookingMessage = document.querySelector("#booking-message");
const closeModalButton = document.querySelector(".close-modal");
const modalTitle = document.querySelector("#modal-title");
const modalPrice = document.querySelector("#modal-price");
const checkInInput = document.querySelector("#check-in");
const checkOutInput = document.querySelector("#check-out");
const guestCountInput = document.querySelector("#guest-count");
const guestLimit = document.querySelector("#guest-limit");
const bookingEstimate = document.querySelector("#booking-estimate");
const decreaseGuestsButton = document.querySelector("#decrease-guests");
const increaseGuestsButton = document.querySelector("#increase-guests");
const currency = new Intl.NumberFormat("en-PH");
let currentRoom;
let lastFocusedElement;

function showAllRooms() {
    document.querySelector('.filter-btn[data-filter="all"]').click();
}

function localDateString(date = new Date()) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
}

function nextDateString(value) {
    const date = value ? new Date(`${value}T00:00:00`) : new Date();
    date.setDate(date.getDate() + 1);
    return localDateString(date);
}

function getNightCount() {
    if (!checkInInput.value || !checkOutInput.value) {
        return 0;
    }

    const [startYear, startMonth, startDay] = checkInInput.value.split("-").map(Number);
    const [endYear, endMonth, endDay] = checkOutInput.value.split("-").map(Number);
    return (Date.UTC(endYear, endMonth - 1, endDay) - Date.UTC(startYear, startMonth - 1, startDay)) / 86400000;
}

function updateDateLimits() {
    checkInInput.min = localDateString();
    checkOutInput.min = nextDateString(checkInInput.value);
    checkOutInput.setCustomValidity("");

    if (checkOutInput.value && checkOutInput.value < checkOutInput.min) {
        checkOutInput.value = "";
    }
}

function updateBookingSummary() {
    if (!currentRoom) {
        return;
    }

    const guests = Number(guestCountInput.value);
    const extraGuests = Math.max(0, guests - currentRoom.includedGuests);
    const nightlyRate = currentRoom.price + extraGuests * currentRoom.extraPrice;
    const nights = getNightCount();

    modalPrice.textContent = `Php ${currency.format(nightlyRate)} per night for ${guests} ${guests === 1 ? "person" : "persons"}.`;
    if (extraGuests > 0) {
        modalPrice.textContent += ` Includes Php ${currency.format(extraGuests * currentRoom.extraPrice)} in extra-person fees per night.`;
    }

    bookingEstimate.textContent = nights > 0
        ? `Estimated total for ${nights} ${nights === 1 ? "night" : "nights"}: Php ${currency.format(nightlyRate * nights)}`
        : "Choose check-in and check-out dates to see the estimated total.";
}

function setGuestCount(value) {
    const guests = Math.min(currentRoom.maxGuests, Math.max(currentRoom.minGuests, Number(value)));
    guestCountInput.value = String(guests);
    guestCountInput.setAttribute("aria-valuetext", `${guests} ${guests === 1 ? "person" : "persons"}`);
    decreaseGuestsButton.disabled = guests <= currentRoom.minGuests;
    increaseGuestsButton.disabled = guests >= currentRoom.maxGuests;
    updateBookingSummary();
}

filterButtons.forEach((button) => {
    button.addEventListener("click", () => {
        const selectedCategory = button.dataset.filter;

        filterButtons.forEach((filterButton) => {
            filterButton.setAttribute("aria-pressed", String(filterButton === button));
        });

        categoryBlocks.forEach((block) => {
            block.hidden = selectedCategory !== "all" && block.dataset.category !== selectedCategory;
        });
    });
});

document.querySelectorAll("[data-show-all]").forEach((link) => {
    link.addEventListener("click", showAllRooms);
});

function closeBooking() {
    bookingModal.classList.remove("is-open");
    bookingModal.setAttribute("aria-hidden", "true");
    bookingMessage.hidden = true;
    lastFocusedElement?.focus();
}

document.querySelectorAll("[data-book-room]").forEach((button) => {
    button.addEventListener("click", () => {
        currentRoom = {
            name: button.dataset.bookRoom,
            price: Number(button.dataset.price),
            minGuests: Number(button.dataset.minGuests),
            defaultGuests: Number(button.dataset.defaultGuests || button.dataset.minGuests),
            includedGuests: Number(button.dataset.includedGuests),
            maxGuests: Number(button.dataset.maxGuests),
            extraPrice: Number(button.dataset.extraPrice)
        };

        modalTitle.textContent = `Book ${currentRoom.name}`;
        guestCountInput.min = String(currentRoom.minGuests);
        guestCountInput.max = String(currentRoom.maxGuests);
        guestLimit.textContent = currentRoom.extraPrice > 0
            ? `Rate covers up to ${currentRoom.includedGuests} persons; Php ${currency.format(currentRoom.extraPrice)} per person over ${currentRoom.includedGuests}, up to ${currentRoom.maxGuests}.`
            : `Rate includes up to ${currentRoom.includedGuests} persons; select ${currentRoom.minGuests} to ${currentRoom.maxGuests} persons.`;
        bookingForm.reset();
        bookingMessage.hidden = true;
        checkInInput.value = "";
        checkOutInput.value = "";
        updateDateLimits();
        setGuestCount(currentRoom.defaultGuests);
        updateBookingSummary();
        lastFocusedElement = button;
        bookingModal.classList.add("is-open");
        bookingModal.setAttribute("aria-hidden", "false");
        document.querySelector("#guest-name").focus();
    });
});

closeModalButton.addEventListener("click", closeBooking);

bookingModal.addEventListener("click", (event) => {
    if (event.target === bookingModal) {
        closeBooking();
    }
});

document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && bookingModal.classList.contains("is-open")) {
        closeBooking();
    }
});

checkInInput.addEventListener("change", () => {
    updateDateLimits();
    updateBookingSummary();
});

checkOutInput.addEventListener("change", updateBookingSummary);
guestCountInput.addEventListener("change", () => setGuestCount(guestCountInput.value));
decreaseGuestsButton.addEventListener("click", () => setGuestCount(Number(guestCountInput.value) - 1));
increaseGuestsButton.addEventListener("click", () => setGuestCount(Number(guestCountInput.value) + 1));

bookingForm.addEventListener("submit", (event) => {
    event.preventDefault();
    if (getNightCount() <= 0) {
        checkOutInput.setCustomValidity("Check-out must be after check-in.");
        checkOutInput.reportValidity();
        return;
    }

    checkOutInput.setCustomValidity("");
    bookingMessage.textContent = "Your request is ready. This demo does not send reservations; please contact Bella Vista to confirm your booking.";
    bookingMessage.hidden = false;
});

checkOutInput.addEventListener("input", () => checkOutInput.setCustomValidity(""));
